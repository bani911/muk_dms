# -*- coding: utf-8 -*-

###################################################################################
# 
#    Copyright (C) 2019 IT Adhimix RMC Indonesia
#
###################################################################################

import os
import re
import json
import base64
import logging
import mimetypes

from odoo import _
from odoo import models, api, fields
from odoo.tools import ustr
from odoo.tools.mimetypes import guess_mimetype
from odoo.exceptions import ValidationError, AccessError

from odoo.addons.muk_dms.models import dms_base

_logger = logging.getLogger(__name__)

# class kalangan_surat(models.Model):
#     _name = 'kalangan.surat'
#
#     name = fields.Char(string="Kalangan", required=True)

# Table pengguna (inherit from res.users)
class pengguna(dms_base.DMSModel):
    _name = 'muk_dms.pengguna'
    _inherit = 'res.users'

    is_staff_dok = fields.Boolean('is Staff Document?')
    is_reviewer_dok = fields.Boolean('is Reviewer Document?')
    is_manager_dok = fields.Boolean('is Manager Document?')
    is_create_disposisi = fields.Boolean('is Pembuat Disposisi?')
    is_receipt_disposisi = fields.Boolean('is Penerima Disposisi?')
    is_administrator_dok = fields.Boolean('is Admin Document?')

# Table dokumen
class dokumen(dms_base.DMSModel):
    _name = 'muk_dms.dokumen'
    _description = "Dokumen"

    name = fields.Char(string="Nama")
    nomor_dokumen = fields.Char(string="No.Dokumen")
    tanggal_dokumen = fields.Date('Tgl.Dokumen')
    deskripsi = fields.Text('Deskripsi')
    pihak = fields.Many2one(comodel_name='res.partner',string="Pihak")
    # tanggal_upload = fields.Datetime('Tgl.Upload', default=lambda *a: (datetime.now() + timedelta(hours=7)).strftime('%Y-%m-%d %H:%M:%S'))
    tanggal_upload = fields.Datetime('Tgl.Upload')
    tanggal_target = fields.Datetime('Tgl.Target')
    tanggal_review = fields.Datetime('Tgl.Review')
    tanggal_done_all = fields.Datetime('Tgl.Done All')
    file_ids = fields.One2many('muk_dms.file', 'dokumen_id', string='File List')
    version = fields.Char(string="Version")
    jenis_dokumen = fields.Selection([('surat_masuk,','Surat Masuk'),('surat_keluar','Surat Keluar'),('naskah','Naskah')],"Status",default="surat_masuk")
    state_naskah = fields.Selection([('draft,','Draft'),('on_review','On Review'),('done','Done'),('done_all','Done All')],"Status Naskah",default="draft")
    state_surat_masuk = fields.Selection([('baru,','Baru'),('disposisi','Disposisi'),('done','Done'),('arsip','Arsip')],"Status Surat Masuk",default="baru")
    state_surat_keluar = fields.Selection([('draft,','Draft'),('on_review','On Review'),('done','Done')],"Status Surat Keluar",default="draft")


# Table muk_dms.file inherit
class file(dms_base.DMSModel):
    _inherit = 'muk_dms.file'

    versi = fields.Char(string="Versi")
    tanggal_versi = fields.Datetime('Tgl.Versi')
    tanggal_upload = fields.Datetime('Tgl.Upload')
    dokumen_id = fields.Many2one(comodel_name='muk_dms.dokumen', string="Ref_Doc")
    is_aktif = fields.Boolean('is Aktif?')

# Table disposisi
class disposisi(dms_base.DMSModel):
    _name = 'muk_dms.disposisi'
    _description = "Disposisi"

    surat_masuk_id = fields.Many2one(comodel_name='muk_dms.dokumen', string="Surat Masuk")
    isi_disposisi = fields.Text('Isi Deskripsi')
    tanggal_disposisi = fields.Datetime('Tgl.Disposisi')
    pembuat_disposisi = fields.Many2one(comodel_name='res.users', string="Pembuat Disposisi")
    disposisi_kepada_ids = fields.One2many('muk_dms.penerima.disposisi', 'disposisi_id', string='List Disposisi')

# Table penerima_disposisi
class penerima_disposisi(dms_base.DMSModel):
    _name = 'muk_dms.penerima.disposisi'
    _description = "Penerima Disposisi"

    disposisi_id = fields.Many2one(comodel_name='muk_dms.disposisi', string="Ref_Disposisi")
    penerima = fields.Many2one(comodel_name='res.users', string="Penerima Disposisi")

# Table review
class review(dms_base.DMSModel):
    _name = 'muk_dms.review'
    _description = "Review"

    reviewer_id = fields.Many2one(comodel_name='muk_dms.pengguna', string="Reviewer")
    bookmark = fields.Char(string="Bookmark")
    redaksi_asal = fields.Text('Redaksi Asal')
    ulasan = fields.Text('Ulasan')
    tanggal_ulasan = fields.Datetime('Tgl.Ulasan')

# Table reviewer
class reviewer(dms_base.DMSModel):
    _name = 'muk_dms.reviewer'
    _description = "Reviewer"

    dokumen_id = fields.Many2one(comodel_name='muk_dms.dokumen', string="Ref_Doc")
    reviewer_id = fields.Many2one(comodel_name='res.users', string="Reviewer")
    tanggal_review = fields.Datetime('Tgl.Review')
    tanggal_done = fields.Datetime('Tgl.Done')
    status_reviewer = fields.Selection([('terima,','Terima'),('on_review','On Review'),('done','Done')],"Status Reviewer",default="draft")


    # settings = fields.Many2one(
    #     'muk_dms.settings',
    #     string="Settings",
    #     store=True,
    #     auto_join=True,
    #     ondelete='restrict',
    #     compute='_compute_settings')
    
    #----------------------------------------------------------
    # Functions
    #----------------------------------------------------------
    
    # def notify_change(self, values, refresh=False, operation=None):
    #     super(File, self).notify_change(values, refresh, operation)
    #     if "index_files" in values:
    #         self._compute_index()
    #     if "save_type" in values:
    #         self._update_reference_type()
            
    #----------------------------------------------------------
    # Read, View 
    #----------------------------------------------------------
        
    # def _compute_settings(self, write=True):
    #     if write:
    #         for record in self:
    #             record.settings = record.directory.settings
    #     else:
    #         self.ensure_one()
    #         return {'settings': self.directory.settings.id}
            
    #----------------------------------------------------------
    # Create, Update, Delete
    #----------------------------------------------------------
    
    # @api.constrains('name')
    # def _check_name(self):
    #     if not self.check_name(self.name):
    #         raise ValidationError("The file name is invalid.")
    #     childs = self.directory.files.mapped(lambda rec: [rec.id, rec.name])
    #     duplicates = [rec for rec in childs if rec[1] == self.name and rec[0] != self.id]
    #     if duplicates:
    #         raise ValidationError("A file with the same name already exists.")
    #
    # def _after_create(self, vals):
    #     record = super(File, self)._after_create(vals)
    #     record._check_recomputation(vals)
    #     return record

    #----------------------------------------------------------
    # Reference
    #----------------------------------------------------------
    
    # def _create_reference(self, settings, path, filename, content):
    #     self.ensure_one()
    #     self.check_access('create', raise_exception=True)
    #     if settings.save_type == 'database':
    #         return self.env['muk_dms.data_database'].sudo().create({'data': content})
    #     return None